package com.Himangi.Tasty.Bites.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stripe.exception.StripeException;
import com.Himangi.Tasty.Bites.Exception.OrderException;
import com.Himangi.Tasty.Bites.model.Address;
import com.Himangi.Tasty.Bites.model.Cart;
import com.Himangi.Tasty.Bites.model.CartItem;
import com.Himangi.Tasty.Bites.model.Order;
import com.Himangi.Tasty.Bites.model.OrderItem;
import com.Himangi.Tasty.Bites.model.PaymentResponse;
import com.Himangi.Tasty.Bites.model.Restaurant;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.repository.AddressRepository;
import com.Himangi.Tasty.Bites.repository.OrderItemRepository;
import com.Himangi.Tasty.Bites.repository.OrderRepository;
import com.Himangi.Tasty.Bites.repository.RestaurantRepository;
import com.Himangi.Tasty.Bites.repository.UserRepository;
import com.Himangi.Tasty.Bites.request.OrderRequest;
@Service
public class OrderServiceImp implements OrderService {
    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private CartSerive cartService;
    @Autowired
    private OrderItemRepository orderItemRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PaymentService paymentSerive;

    @Autowired
    private NotificationService notificationService;
    @Autowired
    private RestaurantService restaurantService;


    @Override
    public Order createOrder(OrderRequest order, User user) throws Exception {

        Address shippAddress = order.getDeliveryAddress();


        Address savedAddress = addressRepository.save(shippAddress);

        if (!user.getAddresses().contains(savedAddress)) {
            user.getAddresses().add(savedAddress);
        }


        System.out.println("user addresses --------------  " + user.getAddresses());

        userRepository.save(user);

        Restaurant restaurant = restaurantService.findRestaurantById(order.getRestaurantId());

        Order createdOrder = new Order();

        createdOrder.setCustomer(user);
        createdOrder.setCreatedAt(new Date());
        createdOrder.setOrderStatus("PENDING");
        createdOrder.setRestaurant(restaurant);
        createdOrder.setDeliveryAddress(savedAddress);

        Cart cart = cartService.findCartByUserId(user.getId());

        List<OrderItem> orderItems = new ArrayList<>();

        for (CartItem cartItem : cart.getItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setFood(cartItem.getFood());
            orderItem.setIngredients(cartItem.getIngredients());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setTotalPrice(cartItem.getTotalPrice());

            OrderItem savedOrderItem = orderItemRepository.save(orderItem);
            orderItems.add(savedOrderItem);
        }

        Long totalPrice = cartService.calculateCartTotals(cart);

        createdOrder.setItems(orderItems);
        createdOrder.setTotalPrice(totalPrice);

        // createdOrder.setItems(orderItems);
        Order savedOrder = orderRepository.save(createdOrder);
        restaurant.getOrders().add(savedOrder);

        //restaurantRepository.save(restaurant.get());


        PaymentResponse res = paymentSerive.createPaymentLink(savedOrder);
        return savedOrder;

    }

    @Override
    public void cancelOrder(Long orderId) throws Exception {
        Order order = findOrderById(orderId);
        orderRepository.deleteById(orderId);

    }

    public Order findOrderById(Long orderId) throws Exception {
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isEmpty()) {
            throw new Exception("Order not found");
        }
return optionalOrder.get();

    }

    @Override
    public List<Order> getUserOrders(Long userId) throws Exception {
        return orderRepository.findByCustomerId(userId);

    }

    @Override
    public List<Order> getRestaurantsOrder(Long restaurantId, String orderStatus) throws Exception {

        List<Order> orders = orderRepository.findByRestaurantId(restaurantId);

        if (orderStatus != null) {
            orders = orders.stream().filter(order ->
                    order.getOrderStatus().equals(orderStatus)).collect(Collectors.toList());
        }
        return orders;
    }

//    private List<MenuItem> filterByVegetarian(List<MenuItem> menuItems, boolean isVegetarian) {
//    return menuItems.stream()
//            .filter(menuItem -> menuItem.isVegetarian() == isVegetarian)
//            .collect(Collectors.toList());
//}


    @Override
    public Order updateOrder(Long orderId, String orderStatus) throws Exception {
        Order order = findOrderById(orderId);

        if (orderStatus.equals("OUT_FOR_DELIVERY")
                || orderStatus.equals("DELIVERED")
                || orderStatus.equals("COMPLETED")
                || orderStatus.equals("PENDING")
        ) {
            order.setOrderStatus(orderStatus);
            //Notification notification=notificationService.sendOrderStatusNotification(order);

            return orderRepository.save(order);
        }

        throw new OrderException("Please Select A Vali  d Order Status");
    }
}

