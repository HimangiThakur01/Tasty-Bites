package com.Himangi.Tasty.Bites.service;

import java.util.List;

import com.Himangi.Tasty.Bites.model.Notification;
import com.Himangi.Tasty.Bites.model.Order;
import com.Himangi.Tasty.Bites.model.Restaurant;
import com.Himangi.Tasty.Bites.model.User;

public interface NotificationService {

    public Notification sendOrderStatusNotification(Order order);
    public void sendRestaurantNotification(Restaurant restaurant, String message);
    public void sendPromotionalNotification(User user, String message);

    public List<Notification> findUsersNotification(Long userId);

}

