package com.Himangi.Tasty.Bites;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TastyBitesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TastyBitesApplication.class, args);
	}

}
