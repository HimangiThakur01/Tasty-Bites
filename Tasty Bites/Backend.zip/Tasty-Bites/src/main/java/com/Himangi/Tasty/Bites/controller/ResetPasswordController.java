package com.Himangi.Tasty.Bites.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Himangi.Tasty.Bites.Exception.UserException;
import com.Himangi.Tasty.Bites.model.PasswordResetToken;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.ResetPasswordRequest;
import com.Himangi.Tasty.Bites.response.MessageResponse;
import com.Himangi.Tasty.Bites.service.PasswordResetTokenService;
import com.Himangi.Tasty.Bites.service.UserService;

@RestController
public class ResetPasswordController {

    @Autowired
    private PasswordResetTokenService passwordResetTokenService;

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<MessageResponse> resetPassword(

            @RequestBody ResetPasswordRequest req) throws Exception {

        PasswordResetToken resetToken = passwordResetTokenService.findByToken(req.getToken());

        if (resetToken == null ) {
            throw new Exception("token is required...");
        }
        if(resetToken.isExpired()) {
            passwordResetTokenService.delete(resetToken);
            throw new Exception("token get expired...");

        }

        // Update user's password
        User user = resetToken.getUser();
        userService.updatePassword(user, req.getPassword());

        // Delete the token
        passwordResetTokenService.delete(resetToken);

        MessageResponse res=new MessageResponse();
        res.setMessage("Password updated successfully.");
        res.setStatus(true);

        return ResponseEntity.ok(res);
    }

    @PostMapping("/reset")
    public ResponseEntity<MessageResponse> resetPassword(@RequestParam("email") String email) throws Exception {
        User user = userService.findUserByEmail(email);
        System.out.println("ResetPasswordController.resetPassword()");

        if (user == null) {
            throw new Exception("user not found");
        }

        userService.sendPasswordResetEmail(user);

        MessageResponse res=new MessageResponse();
        res.setMessage("Password reset email sent successfully.");
        res.setStatus(true);

        return ResponseEntity.ok(res);
    }

}


