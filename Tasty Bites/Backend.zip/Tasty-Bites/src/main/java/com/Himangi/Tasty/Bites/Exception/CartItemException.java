package com.Himangi.Tasty.Bites.Exception;

public class CartItemException extends Exception {
    public CartItemException(String message) {
        super(message);
    }
}
