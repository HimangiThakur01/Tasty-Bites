package com.Himangi.Tasty.Bites.controller;

import java.util.List;

import com.Himangi.Tasty.Bites.Exception.FoodException;
import com.Himangi.Tasty.Bites.Exception.RestaurantException;
import com.Himangi.Tasty.Bites.Exception.UserException;
import com.Himangi.Tasty.Bites.model.Category;
import com.Himangi.Tasty.Bites.model.Restaurant;
import com.Himangi.Tasty.Bites.response.MessageResponse;
import com.Himangi.Tasty.Bites.service.CategoryService;
import com.Himangi.Tasty.Bites.service.RestaurantService;
import jdk.jshell.spi.ExecutionControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Himangi.Tasty.Bites.model.Food;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.CreateFoodRequest;
import com.Himangi.Tasty.Bites.service.FoodService;
import com.Himangi.Tasty.Bites.service.UserService;

@RestController
@RequestMapping("/api/admin/food")
public class AdminFoodController {

    @Autowired
    private FoodService foodService;
    @Autowired
    private UserService userService;
    @Autowired
    private RestaurantService restaurantService;
    @Autowired
    private CategoryService categoryService;

    @PostMapping()
    public ResponseEntity<Food> createFood(
            @RequestBody CreateFoodRequest req,
            @RequestHeader("Authorization") String jwt)
            throws Exception {
        User user = userService.findUserByJwtToken(jwt);
//		Category category=categoryService.findCategoryById(item.getCategoryId());
        Restaurant restaurant=restaurantService.findRestaurantById(req.getRestaurantId());
        //Category category = categoryService.findCategoryById(req.getCategoryId());
        Food food =foodService.createFood(req,req.getCategory(),restaurant);
        return new ResponseEntity<>(food, HttpStatus.CREATED);

    }


    @DeleteMapping("/{id}")
    public ResponseEntity<MessageResponse> deleteFood(@PathVariable Long id,
                                                      @RequestHeader("Authorization") String jwt)
            throws Exception {
        User user = userService.findUserByJwtToken(jwt);

     foodService.deleteFood(id);

        MessageResponse res=new MessageResponse();
        res.setMessage("food deleted successfully");
        return new ResponseEntity<>(res, HttpStatus.CREATED);


    }

    @GetMapping("/search")
    public ResponseEntity<List<Food>> getMenuItemByName(@RequestParam String name)  {
        List<Food> foods=foodService.searchFood(name);
        return new ResponseEntity<>(foods, HttpStatus.OK);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Food> updateFoodAvailabilityStatus(
            @PathVariable Long id, @RequestHeader("Authorization") String jwt)
            throws Exception {
        User user = userService.findUserByJwtToken(jwt);
        Food food =foodService.updateAvailibilityStatus(id);
        return new ResponseEntity<>(food, HttpStatus.CREATED);
    }

}
