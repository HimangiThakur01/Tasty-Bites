package com.Himangi.Tasty.Bites.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Himangi.Tasty.Bites.model.IngredientCategory;
import com.Himangi.Tasty.Bites.model.IngredientsItem;
import com.Himangi.Tasty.Bites.model.Restaurant;
import com.Himangi.Tasty.Bites.repository.IngredientCategoryRepository;
import com.Himangi.Tasty.Bites.repository.IngredientItemRepository;

@Service
public class IngredientServiceImp implements IngredientsService {
    @Autowired
    private IngredientCategoryRepository ingredientCategoryRepository;

    @Autowired
    private IngredientItemRepository ingredientItemRepository;


    @Autowired
    private RestaurantService restaurantService;

    @Override
    public IngredientCategory createIngredientCategory(
            String name, Long restaurantId) throws Exception {

        IngredientCategory isExist = ingredientCategoryRepository
                .findByRestaurantIdAndNameIgnoreCase(restaurantId, name);

        if (isExist != null) {
            return isExist;
        }

        Restaurant restaurant = restaurantService.findRestaurantById(restaurantId);

        IngredientCategory Category = new IngredientCategory();
        Category.setRestaurant(restaurant);
        Category.setName(name);

        return ingredientCategoryRepository.save(Category);
    }

    @Override
    public IngredientCategory findIngredientCategoryById(Long id) throws Exception {
        Optional<IngredientCategory> opt = ingredientCategoryRepository.findById(id);
        if (opt.isEmpty()) {
            throw new Exception("ingredient category not found");
        }
        return opt.get();
    }

    @Override
    public List<IngredientCategory> findIngredientCategoryByRestaurantId(Long id) throws Exception {
        restaurantService.findRestaurantById(id);
        return ingredientCategoryRepository.findByRestaurantId(id);
    }

    @Override
    public List<IngredientsItem> findRestaurantIngredients(Long restaurantId) {

        return ingredientItemRepository.findByRestaurantId(restaurantId);
    }


    @Override
    public IngredientsItem createIngredientItem(Long restaurantId,
                                                 String ingredientName, Long CategoryId) throws Exception {
        IngredientCategory category = findIngredientCategoryById(CategoryId);

        IngredientsItem isExist = ingredientItemRepository.
                findByRestaurantIdAndNameIngoreCase(restaurantId, ingredientName, category.getName());
        if (isExist != null) {
            System.out.println("is exists-------- item");
            return isExist;
        }

        Restaurant restaurant = restaurantService.findRestaurantById(
                restaurantId);
        IngredientsItem item = new IngredientsItem();
        item.setName(ingredientName);
        item.setRestaurant(restaurant);
        item.setCategory(category);

        IngredientsItem savedIngredients = ingredientItemRepository.save(item);
        category.getIngredients().add(savedIngredients);

        return savedIngredients;
    }


    @Override
    public IngredientsItem updateStoke(Long id) throws Exception {
        Optional<IngredientsItem> item = ingredientItemRepository.findById(id);
        if (item.isEmpty()) {
            throw new Exception("ingredient not found with id " + item);
        }
        IngredientsItem ingredient = item.get();
        ingredient.setInStoke(!ingredient.isInStoke());
        return ingredientItemRepository.save(ingredient);
    }
}