package com.Himangi.Tasty.Bites.repository;

import com.Himangi.Tasty.Bites.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {

    public User findByEmailIgnoreCase(String email);

}
