package com.Himangi.Tasty.Bites.request;

import lombok.Data;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Data
public class UpdateCartItemRequest {

    @NotNull(message = "CartItem ID must not be null")
    private Long cartItemId;

    @Min(value = 1, message = "Quantity must be at least 1")
    private int quantity;
}
