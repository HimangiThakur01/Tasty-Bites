package com.Himangi.Tasty.Bites.controller;
import java.util.List;

import com.Himangi.Tasty.Bites.Exception.UserException;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Himangi.Tasty.Bites.Exception.RestaurantException;
import com.Himangi.Tasty.Bites.model.Category;
import com.Himangi.Tasty.Bites.service.CategoryService;

@RestController
@RequestMapping("/api")
public class CategoryController {

    @Autowired
    public CategoryService categoryService;

    @Autowired
    public UserService userService;

    @PostMapping("/admin/category")
    public ResponseEntity<Category> createCategory(
            @RequestBody Category category,
            @RequestHeader("Authorization")String jwt
           ) throws Exception {
        User user=userService.findUserByJwtToken(jwt);

        Category createdCategory=categoryService.createCategory(category.getName(),user.getId());
        return new ResponseEntity<Category>(createdCategory,HttpStatus.OK);
    }

    @GetMapping("/category/restaurant")
    public ResponseEntity<List<Category>> getRestaurantsCategory(
            @RequestHeader("Authorization")String jwt) throws Exception {
        User user=userService.findUserByJwtToken(jwt);
        List<Category> categories=categoryService.findCategoryByRestaurantId(user.getId());
        return new ResponseEntity<>(categories,HttpStatus.OK);
    }

}

