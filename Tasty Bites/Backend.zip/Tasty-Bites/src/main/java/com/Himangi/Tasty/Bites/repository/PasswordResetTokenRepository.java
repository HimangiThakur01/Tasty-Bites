package com.Himangi.Tasty.Bites.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Himangi.Tasty.Bites.model.PasswordResetToken;

public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Integer> {
    PasswordResetToken findByToken(String token);
}