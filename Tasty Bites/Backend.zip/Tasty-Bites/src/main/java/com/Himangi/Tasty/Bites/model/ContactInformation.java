package com.Himangi.Tasty.Bites.model;

import lombok.Data;

@Data
public class ContactInformation {

    private String email;

    private String mobile;

    private String linkedIn;

    private String instagram;
}
