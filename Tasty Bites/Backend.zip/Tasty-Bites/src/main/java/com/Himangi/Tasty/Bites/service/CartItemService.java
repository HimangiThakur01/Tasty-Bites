package com.Himangi.Tasty.Bites.service;

import com.Himangi.Tasty.Bites.model.CartItem;

public interface CartItemService {
    public CartItem createCartItem(CartItem item);
}
