package com.Himangi.Tasty.Bites.response;

public class PaymentResponse {
    private String payment_url;
}
