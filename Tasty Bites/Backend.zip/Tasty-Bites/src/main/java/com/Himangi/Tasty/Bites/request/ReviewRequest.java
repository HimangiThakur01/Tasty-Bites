package com.Himangi.Tasty.Bites.request;

import lombok.Data;

@Data
public class ReviewRequest {
    private Long restaurantId;

    private double rating;

    private String reviewText;
}
