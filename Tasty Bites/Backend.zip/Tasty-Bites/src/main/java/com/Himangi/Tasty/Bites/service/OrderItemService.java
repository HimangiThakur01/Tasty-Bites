package com.Himangi.Tasty.Bites.service;
import com.Himangi.Tasty.Bites.model.OrderItem;

public interface OrderItemService {

    public OrderItem createOrderIem (OrderItem orderItem);

}

