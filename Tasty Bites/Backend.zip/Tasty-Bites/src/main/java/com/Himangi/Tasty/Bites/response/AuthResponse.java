package com.Himangi.Tasty.Bites.response;

import com.Himangi.Tasty.Bites.model.USER_ROLE;

public class AuthResponse {

    private String jwt;
    private String message;
    private USER_ROLE role;

    // ✅ No-arg constructor
    public AuthResponse() {
    }

    // ✅ All-args constructor
    public AuthResponse(String jwt, String message, USER_ROLE role) {
        this.jwt = jwt;
        this.message = message;
        this.role = role;
    }

    // ✅ Getters
    public String getJwt() {
        return jwt;
    }

    public String getMessage() {
        return message;
    }

    public USER_ROLE getRole() {
        return role;
    }

    // ✅ Setters (these were empty before — now fixed)
    public void setJwt(String jwt) {
        this.jwt = jwt;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setRole(USER_ROLE role) {
        this.role = role;
    }
}
