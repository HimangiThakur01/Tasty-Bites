package com.Himangi.Tasty.Bites.service;

import java.util.List;

//import com.stripe.exception.StripeException;
import com.Himangi.Tasty.Bites.model.Order;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.OrderRequest;
public interface OrderService {
    public Order createOrder(OrderRequest order, User user) throws Exception;

    public Order updateOrder(Long orderId, String orderStatus) throws Exception;

    public void cancelOrder(Long orderId) throws Exception;

    public List<Order> getUserOrders(Long userId) throws Exception;

    public List<Order> getRestaurantsOrder(Long restaurantId,String orderStatus) throws Exception;

    public Order findOrderById (Long orderId) throws Exception;
}
