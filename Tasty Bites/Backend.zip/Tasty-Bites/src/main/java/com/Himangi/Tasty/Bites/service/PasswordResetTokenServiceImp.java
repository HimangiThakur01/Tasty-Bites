package com.Himangi.Tasty.Bites.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Himangi.Tasty.Bites.model.PasswordResetToken;
import com.Himangi.Tasty.Bites.repository.PasswordResetTokenRepository;
@Service
public class PasswordResetTokenServiceImp implements PasswordResetTokenService {
    @Autowired
    private PasswordResetTokenRepository passwordResetTokenRepository;

    @Override
    public PasswordResetToken findByToken(String token) {
        PasswordResetToken passwordResetToken =passwordResetTokenRepository.findByToken(token);
        return passwordResetToken;
    }

    @Override
    public void delete(PasswordResetToken resetToken) {
        passwordResetTokenRepository.delete(resetToken);

    }

}
