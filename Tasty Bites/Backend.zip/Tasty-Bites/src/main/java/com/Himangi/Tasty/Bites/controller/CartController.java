package com.Himangi.Tasty.Bites.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Himangi.Tasty.Bites.model.Cart;
import com.Himangi.Tasty.Bites.model.CartItem;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.AddCartItemRequest;
import com.Himangi.Tasty.Bites.request.UpdateCartItemRequest;
import com.Himangi.Tasty.Bites.service.CartSerive;
import com.Himangi.Tasty.Bites.service.UserService;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "*") // ✅ allow frontend to access
public class CartController {

    @Autowired
    private CartSerive cartService;

    @Autowired
    private UserService userService;

    // ✅ GET /api/cart
    @GetMapping
    public ResponseEntity<Cart> findUserCart(@RequestHeader("Authorization") String jwt) throws Exception {
        String token = jwt.substring(7);
        User user = userService.findUserByJwtToken(token);
        Cart cart = cartService.findCartByUserId(user.getId());
        return ResponseEntity.ok(cart);
    }

    // ✅ PUT /api/cart/add
    @PutMapping("/add")
    public ResponseEntity<CartItem> addItemToCart(
            @RequestBody AddCartItemRequest req,
            @RequestHeader("Authorization") String jwt) throws Exception {
        String token = jwt.substring(7);
        CartItem cartItem = cartService.addItemToCart(req, token);
        return ResponseEntity.ok(cartItem);
    }

    // ✅ PUT /api/cart/item/update
    @PutMapping("/item/update")
    public ResponseEntity<CartItem> updateCartItemQuantity(
            @RequestBody UpdateCartItemRequest req,
            @RequestHeader("Authorization") String jwt) throws Exception {
        CartItem cartItem = cartService.updateCartItemQuantity(req.getCartItemId(), req.getQuantity());
        return ResponseEntity.ok(cartItem);
    }

    // ✅ DELETE /api/cart/item/{id}/remove
    @DeleteMapping("/item/{id}/remove")
    public ResponseEntity<Cart> removeCartItem(
            @PathVariable Long id,
            @RequestHeader("Authorization") String jwt) throws Exception {
        String token = jwt.substring(7);
        Cart cart = cartService.removeItemFromCart(id, token);
        return ResponseEntity.ok(cart);
    }

    // ✅ GET /api/cart/total
    @GetMapping("/total")
    public ResponseEntity<Long> calculateCartTotals(
            @RequestHeader("Authorization") String jwt) throws Exception {
        String token = jwt.substring(7);
        User user = userService.findUserByJwtToken(token);
        Cart cart = cartService.findCartByUserId(user.getId());
        Long total = cartService.calculateCartTotals(cart);
        return ResponseEntity.ok(total);
    }

    // ✅ PUT /api/cart/clear
    @PutMapping("/clear")
    public ResponseEntity<Cart> clearCart(
            @RequestHeader("Authorization") String jwt) throws Exception {
        String token = jwt.substring(7);
        User user = userService.findUserByJwtToken(token);
        Cart cart = cartService.clearCart(user.getId());
        return ResponseEntity.ok(cart);
    }
}
