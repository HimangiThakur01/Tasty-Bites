package com.Himangi.Tasty.Bites.request;

import lombok.Data;

@Data
public class ResetPasswordRequest {
    private String password;
    private String token;
}
