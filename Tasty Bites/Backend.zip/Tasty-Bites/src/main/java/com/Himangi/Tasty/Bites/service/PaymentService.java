package com.Himangi.Tasty.Bites.service;

//import com.stripe.exception.StripeException;
import com.Himangi.Tasty.Bites.model.Order;
import com.Himangi.Tasty.Bites.model.PaymentResponse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentService {
    public PaymentResponse createPaymentLink(Order order) throws Exception;
}
