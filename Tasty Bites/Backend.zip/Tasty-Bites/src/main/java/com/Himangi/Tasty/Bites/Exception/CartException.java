package com.Himangi.Tasty.Bites.Exception;

public class CartException extends Exception{
    public CartException(String message) {
        super(message);
    }
}
