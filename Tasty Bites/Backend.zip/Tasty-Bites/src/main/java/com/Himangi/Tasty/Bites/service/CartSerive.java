package com.Himangi.Tasty.Bites.service;

import com.Himangi.Tasty.Bites.Exception.CartException;
import com.Himangi.Tasty.Bites.Exception.CartItemException;
import com.Himangi.Tasty.Bites.Exception.FoodException;
import com.Himangi.Tasty.Bites.Exception.UserException;
import com.Himangi.Tasty.Bites.model.Cart;
import com.Himangi.Tasty.Bites.model.CartItem;
import com.Himangi.Tasty.Bites.model.Food;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.AddCartItemRequest;
import com.Himangi.Tasty.Bites.request.UpdateCartItemRequest;

public interface CartSerive {
    public CartItem addItemToCart(AddCartItemRequest req, String jwt) throws Exception;

    public CartItem updateCartItemQuantity(Long cartItemId,int quantity) throws Exception;

    public Cart removeItemFromCart(Long cartItemId, String jwt) throws Exception;

    public Long calculateCartTotals(Cart cart) throws Exception;

    public Cart findCartById(Long id) throws Exception;

    public Cart findCartByUserId(Long userId) throws Exception;

    public Cart clearCart(Long userId) throws Exception;
}
