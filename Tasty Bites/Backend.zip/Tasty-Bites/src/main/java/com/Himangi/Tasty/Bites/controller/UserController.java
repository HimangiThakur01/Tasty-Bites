package com.Himangi.Tasty.Bites.controller;

import com.Himangi.Tasty.Bites.Exception.UserException;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/profile")
    public ResponseEntity<User> findUserByJwtToken(@RequestHeader("Authorization") String jwt) throws Exception {

        User user = userService.findUserByJwtToken(jwt);
        //user.setPassword(null);
        return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
    }
}
