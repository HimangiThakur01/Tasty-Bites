package com.Himangi.Tasty.Bites.Exception;

public class FoodException extends Exception {
    public FoodException(String message) {
        super(message);

    }
}
