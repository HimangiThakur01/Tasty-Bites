package com.Himangi.Tasty.Bites.request;

import lombok.Data;

@Data
public class IngredientCategoryRequest {
    private Long restaurantId;
    private String name;
}
