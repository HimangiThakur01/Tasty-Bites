package com.Himangi.Tasty.Bites.service;

import com.Himangi.Tasty.Bites.model.PasswordResetToken;

public interface PasswordResetTokenService {

    public PasswordResetToken findByToken(String token);

    public void delete(PasswordResetToken resetToken);

}


