package com.Himangi.Tasty.Bites.controller;

import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

public class SupperAdminController {
    @Autowired
    private UserService userService;

    @GetMapping("/api/customers")
    public ResponseEntity<List<User>> getAllCustomers() {

        List<User> users =userService.findAllUsers();

        return new ResponseEntity<>(users,HttpStatus.ACCEPTED);

    }

    @GetMapping("/api/pending-customers")
    public ResponseEntity<List<User>> getPenddingRestaurantUser(){
        List<User> users=userService.getPendingRestaurantOwner();
        return new ResponseEntity<List<User>>(users, HttpStatus.ACCEPTED);

    }
}
