package com.Himangi.Tasty.Bites.request;

import lombok.Data;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
public class AddCartItemRequest {

    @NotNull(message = "Food ID must not be null")
    private Long foodId;

    @Min(value = 1, message = "Quantity must be at least 1")
    private int quantity;

    private List<String> ingredients; // Optional, can be null or empty
}
