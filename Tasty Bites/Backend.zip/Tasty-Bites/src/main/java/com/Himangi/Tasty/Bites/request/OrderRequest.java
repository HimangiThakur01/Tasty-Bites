package com.Himangi.Tasty.Bites.request;

import com.Himangi.Tasty.Bites.model.Address;
import lombok.Data;

@Data
public class OrderRequest {
    private Long restaurantId;

    private Address deliveryAddress;
}
