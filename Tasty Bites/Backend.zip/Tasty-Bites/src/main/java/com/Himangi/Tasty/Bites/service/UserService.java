package com.Himangi.Tasty.Bites.service;

import java.util.List;
import com.Himangi.Tasty.Bites.model.User;



public interface UserService {
    public User findUserByJwtToken(String jwt) throws Exception;

    public User findUserByEmail(String email) throws Exception;

    //User findUserByJwtToken(String jwt) throws Exception;

    public List<User> findAllUsers();

    public List<User> getPendingRestaurantOwner();

    void updatePassword(User user, String newPassword);

    void sendPasswordResetEmail(User user);
}
