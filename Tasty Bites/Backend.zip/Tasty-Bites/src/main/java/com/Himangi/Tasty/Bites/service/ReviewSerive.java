package com.Himangi.Tasty.Bites.service;

import java.util.List;

import com.Himangi.Tasty.Bites.Exception.ReviewException;
import com.Himangi.Tasty.Bites.model.Review;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.ReviewRequest;

public interface ReviewSerive {

    public Review submitReview(ReviewRequest review,User user);
    public void deleteReview(Long reviewId) throws ReviewException;
    public double calculateAverageRating(List<Review> reviews);
}
