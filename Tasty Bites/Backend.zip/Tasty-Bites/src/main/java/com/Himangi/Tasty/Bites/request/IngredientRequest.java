package com.Himangi.Tasty.Bites.request;

import lombok.Data;

@Data
public class IngredientRequest {
    private Long restaurantId;
    private String name;
    private Long CategoryId;
}
