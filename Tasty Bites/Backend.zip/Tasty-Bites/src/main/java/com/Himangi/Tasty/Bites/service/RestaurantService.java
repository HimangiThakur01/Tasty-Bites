package com.Himangi.Tasty.Bites.service;

import com.Himangi.Tasty.Bites.dto.RestaurantDto;
import com.Himangi.Tasty.Bites.model.Restaurant;
import com.Himangi.Tasty.Bites.model.User;
import com.Himangi.Tasty.Bites.request.CreateRestaurantRequest;

import java.util.List;

public interface RestaurantService {
    public Restaurant createRestaurant(CreateRestaurantRequest req, User user);

    public Restaurant updateRestaurant(Long restaurantId, CreateRestaurantRequest updatedRestaurant)
            throws Exception;

    public void deleteRestaurant(Long restaurantId) throws Exception;

    public List<Restaurant>getAllRestaurant();

    Restaurant getRestaurantsByUserId(Long userId) throws Exception;

    public List<Restaurant> searchRestaurant(String keyword);

    public Restaurant findRestaurantById(Long id) throws Exception;

    public Restaurant getRestaurantByUserId(Long userId) throws Exception;

    public RestaurantDto addToFavorites(Long restaurantId, User user) throws Exception;

    public Restaurant updateRestaurantStatus(Long id)throws Exception;
}


